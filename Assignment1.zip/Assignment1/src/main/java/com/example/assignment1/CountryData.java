package com.example.assignment1;

    public class CountryData {
    private String country;
    private Double data2022;

    private int id;

    // Constructor
    public CountryData(int id, String country, double data2022) {
        this.id = id;
        this.country = country;
        this.data2022 = data2022;
    }

    // Getters and setters

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public double getData2022() {
        return data2022;
    }

    public void setData2022(double data2022) {

        this.data2022 = data2022;
    }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }
