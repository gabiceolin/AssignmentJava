package com.example.assignment1;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private BarChart<String, Number> polutionChart;

    @FXML
    private Button button;

    @FXML
    private void handleButtonAction(ActionEvent event) {
        HelloApplicationTable a = new HelloApplicationTable();
        try {
            a.start(new Stage());
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private final DatabaseConnector connector = new DatabaseConnector();

    private void showTableData() {
        //tableView.getItems().clear(); // Clear existing data

        XYChart.Series series = new XYChart.Series();


        try (Connection conn = connector.getConnection()) {
            Statement stmt = conn.createStatement();
            System.out.println("Database connection established successfully!");
            ResultSet rs = stmt.executeQuery("SELECT * FROM countries ORDER BY Data_2022 DESC ");

            // Populate the TableView with data from the result set
            while (rs.next()) {
                String country = rs.getString("Country");
                double data2022 = rs.getDouble("Data_2022");
                int id = rs.getInt("ID");

                series.getData().add(new XYChart.Data(country,data2022));


            }
            // Close the result set and statement
            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        polutionChart.getData().add(series);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showTableData();
    }

}