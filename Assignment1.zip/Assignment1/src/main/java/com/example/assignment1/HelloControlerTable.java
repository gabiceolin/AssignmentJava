package com.example.assignment1;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class HelloControlerTable implements Initializable {

    @FXML
    private TableView<CountryData> table;

    @FXML
    private TableColumn<CountryData, Integer> ID;

    @FXML
    private TableColumn<CountryData, String> Country;

    @FXML
    private TableColumn<CountryData, Double> Data;

    private final DatabaseConnector connector = new DatabaseConnector();

    private void showTableData() {
        //tableView.getItems().clear(); // Clear existing data

        try (Connection conn = connector.getConnection()) {
            Statement stmt = conn.createStatement();
            System.out.println("Database connection established successfully!");
            ResultSet rs = stmt.executeQuery("SELECT * FROM countries ORDER BY Data_2022 DESC ");

            // Populate the TableView with data from the result set
            while (rs.next()) {
                String country = rs.getString("Country");
                double data2022 = rs.getDouble("Data_2022");
                int id = rs.getInt("ID");

               table.getItems().add(new CountryData(id,country,data2022));

            }
            // Close the result set and statement
            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showTableData();
        ID.setCellValueFactory(new PropertyValueFactory<CountryData, Integer>("id"));
        Country.setCellValueFactory(new PropertyValueFactory<CountryData, String>("country"));
        Data.setCellValueFactory(new PropertyValueFactory<CountryData, Double>("data2022"));
    }

}

