use testDB;

CREATE TABLE countries (ID INT PRIMARY KEY AUTO_INCREMENT,
    Country VARCHAR(100),
    Data_2022 VARCHAR(255)
);

INSERT INTO Countries (Country, Data_2022)
VALUES 
    ('Chad', '89.7'),
    ('Iraq', '80.1'),
    ('Pakistan', '70.9'),
    ('Bahrain', '66.6'),
    ('Bangladesh', '65.8'),
    ('Burkina Faso', '63'),
    ('Kuwait', '55.8'),
    ('India', '53.3'),
    ('Egypt', '46.5'),
    ('Tajikistan', '45.0');
    
